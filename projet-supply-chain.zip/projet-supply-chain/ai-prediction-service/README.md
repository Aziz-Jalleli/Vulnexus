# Service de prédiction IA

Service Python (FastAPI) du projet. Il fait deux choses :

1. **Prédit le risque de maintenance d'une dépendance** (`low`, `medium`, `high`) avec un modèle **XGBoost** entraîné sur l'historique des versions de 3 000 paquets npm.
2. **Calcule un score de risque contextuel (0 à 100)** pour une vulnérabilité, par une somme pondérée à poids fixes (pas de ML).

## Démarrage

```bash
pip install -r requirements-dev.txt
python3 -m pytest -q                          # 29 tests
python3 -m uvicorn app.main:app --port 8000   # documentation interactive : http://localhost:8000/docs
```

Avec Docker (depuis la racine du dépôt) : `docker compose --profile ai up -d --build`

## API

| Méthode | Route | Rôle |
|---|---|---|
| GET | `/health` | État du service et version du modèle |
| GET | `/v1/model-info` | Caractéristiques, métriques de test, limites |
| POST | `/v1/maintenance-risk` | Risque de maintenance d'un paquet |
| POST | `/v1/maintenance-risk/batch` | Jusqu'à 500 paquets (un scan complet) |
| POST | `/v1/risk-score` | Score de risque contextuel d'une vulnérabilité |

### Exemple : risque de maintenance

L'appelant (service Java) envoie la liste des versions avec leurs dates de publication.

```bash
curl -s localhost:8000/v1/maintenance-risk -H 'Content-Type: application/json' -d '{
  "ecosystem": "npm",
  "package": "exemple",
  "deprecated": false,
  "releases": [
    {"version": "1.0.0", "published_at": "2019-03-01T10:00:00Z"},
    {"version": "1.1.0", "published_at": "2020-06-15T10:00:00Z"},
    {"version": "1.2.0", "published_at": "2021-01-20T10:00:00Z"}
  ]
}'
```

Réponse (valeurs d'exemple) :

```json
{
  "package": "exemple", "ecosystem": "npm", "level": "high",
  "probabilities": {"low": 0.05, "medium": 0.06, "high": 0.89},
  "top_factors": [
    {"feature": "days_since_last_release", "label": "jours depuis la dernière version", "value": 2100.0, "contribution": 0.93}
  ],
  "deprecated_override": false, "model_version": "xgb-npm-2026-11-27", "warnings": []
}
```

- `top_factors` : les 3 caractéristiques qui poussent le plus vers le niveau prédit (valeurs SHAP natives de XGBoost), pour l'explication affichée dans le tableau de bord.
- `deprecated: true` impose `high` (état connu, pas une prédiction) ; `deprecated_override` l'indique et les probabilités restent celles du modèle.
- Le champ `warnings` signale les cas peu fiables (écosystème autre que npm, moins de 3 versions).

### Exemple : score de risque

```bash
curl -s localhost:8000/v1/risk-score -H 'Content-Type: application/json' -d '{
  "vulnerability_id": "GHSA-jfh8-c2jp-5v3q", "cvss": 10, "known_exploited": true,
  "scope": "production", "relation": "direct", "maintenance_risk": "low"}'
# => {"score": 92, "priority": "critical", "breakdown": {"severity": 35.0, "exploitability": 25.0, "exposure": 20.0, "dependency": 12.0}, ...}
```

| Composante | Poids | Calcul |
|---|---|---|
| Sévérité | 35 | 35 × CVSS / 10 |
| Exploitabilité | 25 | 25 × (1 si exploitation connue, sinon probabilité d'exploitation, sinon 0) |
| Exposition | 20 | 20 × (1 en production, 0,25 en développement ou test) |
| Importance de la dépendance | 20 | 12 × (1 direct, 0,6 transitif) + 8 × (0 low, 0,5 medium, 1 high) |

Priorité : ≥ 80 critical, ≥ 60 high, ≥ 40 medium, sinon low. **Ces poids sont des valeurs initiales choisies à la main**, à réviser avec l'équipe.

## Le modèle

**Caractéristiques (13)**, toutes calculées à partir de l'historique des versions et **avant** la date d'évaluation : jours depuis la dernière version (et la dernière stable), versions sur 6 mois, 12 mois et les 12 mois précédents, tendance, nombre total de versions, âge, délai moyen et médian entre versions, irrégularité, nombre de versions majeures, part de pré-versions.

**Étiquette** (ce qui se passe dans les 12 mois suivants) : `high` = dernière version dépréciée ou aucune version publiée ; `medium` = 1 seule version ; `low` = 2 versions ou plus.

**Validation dans le temps** : entraînement avec T = 2024-11-27, test avec T = 2025-11-27 (futur jamais vu par le modèle).

| Modèle (test, 2 970 paquets) | F1 macro | IC 95 % |
|---|---|---|
| Classe majoritaire | 0,228 | [0,223 ; 0,233] |
| Règle simple (jours sans version) | 0,581 | [0,564 ; 0,599] |
| Régression logistique | 0,608 | [0,591 ; 0,624] |
| **XGBoost** | **0,612** | [0,595 ; 0,629] |

**Lecture honnête :**
- XGBoost bat la règle simple, mais de peu (différence de +0,01 à +0,05 de F1 macro).
- **Il n'est pas significativement meilleur que la régression logistique** (différence entre −0,008 et +0,015, intervalle contenant 0). Le gain d'XGBoost tient surtout à ses explications SHAP natives et à sa capacité à évoluer quand on ajoutera des caractéristiques (GitHub).
- La classe `medium` est mal prédite (F1 ≈ 0,24).
- `high` ne veut pas dire « dangereux » : beaucoup de bibliothèques populaires sont terminées et stables.

Détails, matrice de confusion et résultats sur les paquets encore actifs : [`reports/EVALUATION.md`](reports/EVALUATION.md).

## Limites connues

- **npm uniquement.** Aucun jeu de données Maven (Maven Central n'est pas accessible depuis l'environnement où ce modèle a été construit). Le service accepte `ecosystem: "Maven"` mais renvoie un avertissement : le résultat n'est pas validé.
- **Une seule source de signaux** : l'historique des versions. Les commits, issues et contributeurs (API GitHub) ne sont pas utilisés, faute de jeton d'accès pour collecter à grande échelle.
- **Paquets populaires uniquement** (liste `npm-high-impact`).
- La date de dépréciation d'un paquet n'est pas connue, seulement son état actuel.

## Reproduire l'entraînement

```bash
python3 training/collect_npm.py --n 3000   # ~30 s ; écrit data/npm_release_history.jsonl.gz (reprise automatique)
python3 training/build_dataset.py          # data/dataset_{train,test}.csv
python3 training/train.py                  # ~75 s ; écrit models/ et reports/
```

La collecte lit `data/collection_meta.json` (date de collecte) : pour refaire une collecte à une nouvelle date, mettre ce fichier à jour avant de lancer `build_dataset.py`.

## Structure

```
app/            service (main, schemas, model, features, scoring)
training/       collecte, construction du jeu de données, entraînement
data/           historiques npm (gz), jeux train/test, métadonnées
models/         maintenance_risk.json (XGBoost), metadata.json
reports/        metrics.json, EVALUATION.md
tests/          29 tests, dont la parité entraînement / service
```

`app/features.py` est partagé par l'entraînement et le service : les caractéristiques ne peuvent pas diverger. Le test `test_train_serve_parity` le vérifie sur 25 paquets réels.
