# Évaluation du classifieur de risque de maintenance

*Fichier généré par `training/train.py` : ne pas modifier à la main.*

## Protocole

| | Entraînement | Test |
|---|---|---|
| Date T (caractéristiques calculées avant T) | 2024-11-27 | 2025-11-27 |
| Fenêtre d'étiquetage (12 mois après T) | jusqu'au 2025-11-27 | jusqu'au 2026-11-27 |
| Paquets | 2864 | 2970 |
| high / medium / low | 1483 / 255 / 1126 | 1543 / 215 / 1212 |

Le test porte sur un futur que le modèle n'a pas vu : toutes les étiquettes d'entraînement sont connues avant la date T du test.
Les hyperparamètres de XGBoost sont réglés par validation croisée (5 plis) sur l'entraînement uniquement.

**Étiquette (ce qui se passe dans les 12 mois suivant T) :** `high` = dernière version dépréciée OU aucune version publiée ;
`medium` = exactement 1 version ; `low` = 2 versions ou plus.

## Résultats sur le jeu de test (tous les paquets)

| Modèle | F1 macro | IC 95 % | Exactitude | F1 low | F1 medium | F1 high |
|---|---|---|---|---|---|---|
| Classe majoritaire | 0.228 | [0.223 ; 0.233] | 0.520 | 0.000 | 0.000 | 0.684 |
| Règle simple (jours sans version) | 0.581 | [0.564 ; 0.599] | 0.728 | 0.814 | 0.168 | 0.760 |
| Régression logistique | 0.608 | [0.591 ; 0.624] | 0.713 | 0.784 | 0.224 | 0.816 |
| XGBoost | 0.612 | [0.595 ; 0.629] | 0.715 | 0.793 | 0.237 | 0.806 |

Différence XGBoost − règle simple (F1 macro) : IC 95 % bootstrap [+0.010 ; +0.050].
Différence XGBoost − régression logistique : [-0.008 ; +0.015] : différence non significative (l'intervalle contient 0).

## Résultats sur les paquets encore actifs à la date T (1506 paquets, au moins 1 version sur les 12 mois précédents)

C'est le cas le plus utile : prédire si un paquet actif va s'arrêter. La règle « jours sans version » y est moins informative.

| Modèle | F1 macro | IC 95 % | Exactitude | F1 low | F1 medium | F1 high |
|---|---|---|---|---|---|---|
| Classe majoritaire | 0.107 | [0.097 ; 0.117] | 0.191 | 0.000 | 0.000 | 0.321 |
| Règle simple (jours sans version) | 0.282 | [0.277 ; 0.287] | 0.734 | 0.847 | 0.000 | 0.000 |
| Régression logistique | 0.452 | [0.423 ; 0.480] | 0.637 | 0.825 | 0.251 | 0.280 |
| XGBoost | 0.471 | [0.445 ; 0.497] | 0.652 | 0.834 | 0.245 | 0.333 |

Différence XGBoost − règle simple (F1 macro) : IC 95 % bootstrap [+0.161 ; +0.217].
(Sur ce sous-ensemble, la règle ne peut prédire que `low` puisque tous ces paquets ont publié il y a moins de 365 jours : la comparaison avec elle est donc peu exigeante.)
Différence XGBoost − régression logistique : [-0.006 ; +0.042] : différence non significative (l'intervalle contient 0).

## Matrice de confusion XGBoost (test, lignes = réel, colonnes = prédit : low, medium, high)

| | low | medium | high |
|---|---|---|---|
| **low** | 842 | 261 | 109 |
| **medium** | 22 | 107 | 86 |
| **high** | 48 | 321 | 1174 |

## Caractéristiques les plus influentes (moyenne des |valeurs SHAP|)

1. `days_since_last_release` : 0.322
2. `releases_12m` : 0.295
3. `days_since_last_stable_release` : 0.176
4. `gap_cv` : 0.099
5. `mean_gap_days` : 0.085
6. `median_gap_days` : 0.066

## Limites

- **« high » ne veut pas dire « dangereux » :** beaucoup de bibliothèques populaires sont terminées et stables (aucune nouvelle version ne signifie parfois « rien à corriger »). L'étiquette mesure l'absence de maintenance attendue, pas un défaut.
- **Une seule source de signaux :** l'historique des versions du registre npm. Les commits, issues et contributeurs (API GitHub) ne sont pas encore utilisés.
- **npm uniquement :** aucun jeu de données Maven n'a été collecté (Maven Central n'est pas accessible depuis l'environnement de développement). Appliquer le modèle à Maven est une extrapolation non validée.
- **Dépréciation :** le drapeau « déprécié » est l'état actuel ; sa date n'est pas connue.
- **Paquets populaires uniquement** (liste `npm-high-impact`) : les résultats ne s'appliquent pas forcément à de petits paquets.
