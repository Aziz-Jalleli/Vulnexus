"""Chargement du modèle XGBoost et prédiction du risque de maintenance."""
from __future__ import annotations

import json
import math
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import xgboost as xgb

from .features import FEATURE_LABELS, FEATURE_NAMES, LABELS, compute_features, feature_vector, to_utc
from .schemas import Factor, MaintenanceRiskRequest, MaintenanceRiskResponse

MODEL_DIR = Path(os.environ.get("MODEL_DIR", Path(__file__).resolve().parent.parent / "models"))


class NoReleaseError(ValueError):
    """Aucune version publiée à la date d'évaluation."""


class MaintenanceModel:
    def __init__(self, model_dir: Path = MODEL_DIR):
        self.meta = json.load(open(model_dir / "metadata.json", encoding="utf-8"))
        if self.meta["features"] != FEATURE_NAMES:
            raise RuntimeError("Les caractéristiques du modèle ne correspondent pas au code : réentraîner le modèle.")
        self.booster = xgb.Booster()
        self.booster.load_model(str(model_dir / "maintenance_risk.json"))
        self._lock = threading.Lock()  # Booster.predict n'est pas garanti thread-safe

    @property
    def version(self) -> str:
        return self.meta["model_version"]

    def predict(self, req: MaintenanceRiskRequest) -> MaintenanceRiskResponse:
        as_of = to_utc(req.as_of) if req.as_of else datetime.now(timezone.utc)
        releases = [(r.version, r.published_at) for r in req.releases]
        feats = compute_features(releases, as_of)
        if feats is None:
            raise NoReleaseError(f"{req.package} : aucune version publiée avant {as_of.isoformat()}")

        dm = xgb.DMatrix(np.array([feature_vector(feats)], dtype=float), feature_names=FEATURE_NAMES)
        with self._lock:
            proba = self.booster.predict(dm)[0]
            contrib = self.booster.predict(dm, pred_contribs=True)[0]  # (classes, features + 1)

        probs = {LABELS[i]: float(proba[i]) for i in range(len(LABELS))}
        model_class = int(np.argmax(proba))

        # Facteurs qui poussent le plus vers la classe retenue par le modèle
        c = contrib[model_class][:-1]
        order = np.argsort(-c)[:3]
        factors = []
        for i in order:
            v = feats[FEATURE_NAMES[i]]
            factors.append(Factor(feature=FEATURE_NAMES[i], label=FEATURE_LABELS[FEATURE_NAMES[i]],
                                  value=None if math.isnan(v) else round(float(v), 2),
                                  contribution=round(float(c[i]), 4)))

        level = LABELS[model_class]
        override = False
        if req.deprecated:  # état connu, pas une prédiction
            level, override = "high", True

        warnings = []
        if req.ecosystem != "npm":
            warnings.append("Le modèle est entraîné sur npm uniquement : résultat non validé pour cet écosystème.")
        if len(req.releases) < 3:
            warnings.append("Moins de 3 versions connues : prédiction peu fiable.")
        if override:
            warnings.append("Niveau 'high' imposé par le drapeau 'déprécié' ; les probabilités restent celles du modèle.")

        return MaintenanceRiskResponse(
            package=req.package, ecosystem=req.ecosystem, level=level, probabilities=probs,
            top_factors=factors, deprecated_override=override, model_version=self.version, warnings=warnings,
        )
