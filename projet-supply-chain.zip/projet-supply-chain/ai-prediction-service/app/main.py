"""Service de prédiction IA (FastAPI).

    GET  /health
    GET  /v1/model-info
    POST /v1/maintenance-risk          un paquet
    POST /v1/maintenance-risk/batch    jusqu'à 500 paquets (un scan complet)
    POST /v1/risk-score                score de risque contextuel d'une vulnérabilité
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request

from .model import MaintenanceModel, NoReleaseError
from .schemas import (BatchRequest, BatchResponse, MaintenanceRiskRequest, MaintenanceRiskResponse,
                      RiskScoreRequest, RiskScoreResponse)
from .scoring import risk_score


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.model = MaintenanceModel()
    yield


app = FastAPI(title="Service de prédiction IA", version="0.1.0", lifespan=lifespan)


def _model(request: Request) -> MaintenanceModel:
    return request.app.state.model


@app.get("/health")
def health(request: Request):
    m = _model(request)
    return {"status": "ok", "model_loaded": True, "model_version": m.version}


@app.get("/v1/model-info")
def model_info(request: Request):
    m = _model(request).meta
    return {
        "model_version": m["model_version"],
        "trained_at": m["trained_at"],
        "trained_on": m["trained_on"],
        "labels": m["labels"],
        "features": m["features"],
        "test_macro_f1": m["test_macro_f1"],
        "dataset": m["dataset"],
        "limitations": [
            "Entraîné sur npm uniquement ; résultat non validé pour Maven.",
            "Signal unique : historique des versions (pas de commits ni d'issues).",
            "'high' signifie 'aucune maintenance attendue', pas 'dangereux'.",
        ],
    }


def _predict(model: MaintenanceModel, item: MaintenanceRiskRequest) -> MaintenanceRiskResponse:
    try:
        return model.predict(item)
    except NoReleaseError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/v1/maintenance-risk", response_model=MaintenanceRiskResponse)
def maintenance_risk(item: MaintenanceRiskRequest, request: Request):
    return _predict(_model(request), item)


@app.post("/v1/maintenance-risk/batch", response_model=BatchResponse)
def maintenance_risk_batch(batch: BatchRequest, request: Request):
    model = _model(request)
    return BatchResponse(results=[_predict(model, it) for it in batch.items])


@app.post("/v1/risk-score", response_model=RiskScoreResponse)
def score(req: RiskScoreRequest):
    return risk_score(req)
