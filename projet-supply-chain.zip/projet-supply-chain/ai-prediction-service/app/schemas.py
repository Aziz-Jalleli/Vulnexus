"""Schémas typés des requêtes et réponses du service."""
from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field

Level = Literal["low", "medium", "high"]


# ---------------------------------------------------------------- risque de maintenance
class ReleaseIn(BaseModel):
    version: str = Field(min_length=1, examples=["1.2.3"])
    published_at: datetime = Field(examples=["2024-05-17T09:30:00Z"])


class MaintenanceRiskRequest(BaseModel):
    ecosystem: Literal["npm", "Maven"] = "npm"
    package: str = Field(min_length=1, examples=["lodash"])
    releases: list[ReleaseIn] = Field(min_length=1, max_length=20000)
    deprecated: bool = Field(False, description="La dernière version est marquée dépréciée par le mainteneur.")
    as_of: Optional[datetime] = Field(None, description="Date d'évaluation (par défaut : maintenant, UTC).")


class Factor(BaseModel):
    feature: str
    label: str
    value: Optional[float]
    contribution: float = Field(description="Contribution SHAP vers la classe prédite (positive = pousse vers elle).")


class MaintenanceRiskResponse(BaseModel):
    package: str
    ecosystem: str
    level: Level
    probabilities: dict[Level, float]
    top_factors: list[Factor]
    deprecated_override: bool = Field(description="Vrai si le niveau 'high' vient du drapeau 'déprécié' et non du modèle.")
    model_version: str
    warnings: list[str]


class BatchRequest(BaseModel):
    items: list[MaintenanceRiskRequest] = Field(min_length=1, max_length=500)


class BatchResponse(BaseModel):
    results: list[MaintenanceRiskResponse]


# ---------------------------------------------------------------- score de risque contextuel
class RiskScoreRequest(BaseModel):
    vulnerability_id: str = Field(examples=["GHSA-jfh8-c2jp-5v3q"])
    cvss: float = Field(ge=0, le=10, description="Score CVSS de base, de 0 à 10.")
    known_exploited: bool = Field(False, description="Exploitation active connue (ex. catalogue KEV de la CISA).")
    exploit_probability: Optional[float] = Field(None, ge=0, le=1, description="Probabilité d'exploitation (ex. EPSS), 0 à 1.")
    scope: Literal["production", "development"] = "production"
    relation: Literal["direct", "transitive"] = "direct"
    maintenance_risk: Optional[Level] = None


class RiskScoreResponse(BaseModel):
    vulnerability_id: str
    score: int = Field(ge=0, le=100)
    priority: Literal["critical", "high", "medium", "low"]
    breakdown: dict[str, float]
    weights_version: str
