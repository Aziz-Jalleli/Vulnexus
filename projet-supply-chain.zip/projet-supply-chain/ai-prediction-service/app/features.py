"""Caractéristiques du risque de maintenance.

Ce module est utilisé À LA FOIS par l'entraînement et par le service : une seule
définition des caractéristiques, pour qu'elles ne divergent jamais.

Règle anti-fuite : seules les versions publiées à la date `as_of` ou avant sont utilisées.
"""
from __future__ import annotations

import math
import statistics
from datetime import datetime, timedelta, timezone
from typing import Iterable, Sequence

# (numéro de version, date de publication)
Release = tuple[str, datetime]

FEATURE_NAMES: list[str] = [
    "days_since_last_release",
    "days_since_last_stable_release",
    "releases_6m",
    "releases_12m",
    "releases_prev_12m",
    "releases_trend",
    "releases_total",
    "age_days",
    "mean_gap_days",
    "median_gap_days",
    "gap_cv",
    "major_versions",
    "prerelease_share_12m",
]

# Libellés lisibles pour l'explication (tableau de bord)
FEATURE_LABELS: dict[str, str] = {
    "days_since_last_release": "jours depuis la dernière version",
    "days_since_last_stable_release": "jours depuis la dernière version stable",
    "releases_6m": "versions publiées sur 6 mois",
    "releases_12m": "versions publiées sur 12 mois",
    "releases_prev_12m": "versions publiées entre 12 et 24 mois",
    "releases_trend": "évolution du rythme de publication (12 mois vs 12 mois précédents)",
    "releases_total": "nombre total de versions",
    "age_days": "âge du paquet (jours)",
    "mean_gap_days": "délai moyen entre deux versions (jours)",
    "median_gap_days": "délai médian entre deux versions (jours)",
    "gap_cv": "irrégularité des publications",
    "major_versions": "nombre de versions majeures",
    "prerelease_share_12m": "part de pré-versions sur 12 mois",
}

NAN = float("nan")


def to_utc(dt: datetime) -> datetime:
    """Datetime sensible au fuseau, en UTC (les dates naïves sont supposées UTC)."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def parse_iso(value: str) -> datetime:
    return to_utc(datetime.fromisoformat(value.replace("Z", "+00:00")))


def _is_prerelease(version: str) -> bool:
    # semver : un suffixe "-xxx" (avant d'éventuelles métadonnées "+build") = pré-version
    return "-" in version.split("+", 1)[0]


def _major(version: str) -> str:
    return version.lstrip("vV").split(".", 1)[0].split("-", 1)[0]


def compute_features(releases: Iterable[Release], as_of: datetime) -> dict[str, float] | None:
    """Calcule les caractéristiques à la date `as_of`.

    Retourne None si le paquet n'a aucune version publiée à cette date.
    """
    as_of = to_utc(as_of)
    rel = sorted(((v, to_utc(d)) for v, d in releases if to_utc(d) <= as_of), key=lambda x: x[1])
    if not rel:
        return None

    def n_between(days_from: int, days_to: int) -> int:
        lo, hi = as_of - timedelta(days=days_to), as_of - timedelta(days=days_from)
        return sum(1 for _, d in rel if lo < d <= hi)

    last = rel[-1][1]
    stable = [d for v, d in rel if not _is_prerelease(v)]

    gaps = [(b[1] - a[1]).total_seconds() / 86400 for a, b in zip(rel, rel[1:])]
    mean_gap = statistics.fmean(gaps) if gaps else NAN
    median_gap = statistics.median(gaps) if gaps else NAN
    gap_cv = (statistics.pstdev(gaps) / mean_gap) if len(gaps) >= 2 and mean_gap > 0 else NAN

    r12 = n_between(0, 365)
    r_prev = n_between(365, 730)
    in_12m = [v for v, d in rel if d > as_of - timedelta(days=365)]
    pre_share = (sum(_is_prerelease(v) for v in in_12m) / len(in_12m)) if in_12m else NAN

    return {
        "days_since_last_release": (as_of - last).total_seconds() / 86400,
        "days_since_last_stable_release": ((as_of - stable[-1]).total_seconds() / 86400) if stable else NAN,
        "releases_6m": n_between(0, 183),
        "releases_12m": r12,
        "releases_prev_12m": r_prev,
        "releases_trend": r12 - r_prev,
        "releases_total": len(rel),
        "age_days": (as_of - rel[0][1]).total_seconds() / 86400,
        "mean_gap_days": mean_gap,
        "median_gap_days": median_gap,
        "gap_cv": gap_cv,
        "major_versions": len({_major(v) for v, _ in rel}),
        "prerelease_share_12m": pre_share,
    }


def feature_vector(features: dict[str, float]) -> list[float]:
    return [features[name] for name in FEATURE_NAMES]


# ---------------------------------------------------------------------------
# Étiquettes (entraînement uniquement) : ce qui se passe APRÈS la date T.
# ---------------------------------------------------------------------------
LABELS = ["low", "medium", "high"]
LABEL_WINDOW_DAYS = 365      # fenêtre d'observation après T
MEDIUM_MAX_RELEASES = 1      # 1 seule version dans la fenêtre = maintenance minimale


def label_outcome(releases: Sequence[Release], deprecated: bool, start: datetime, end: datetime) -> str:
    """Étiquette selon les versions publiées dans (start, end].

    high   : dernière version dépréciée, OU aucune version dans la fenêtre
    medium : exactement 1 version dans la fenêtre
    low    : 2 versions ou plus dans la fenêtre
    """
    start, end = to_utc(start), to_utc(end)
    n = sum(1 for _, d in releases if start < to_utc(d) <= end)
    if deprecated or n == 0:
        return "high"
    if n <= MEDIUM_MAX_RELEASES:
        return "medium"
    return "low"
