"""Score de risque contextuel : somme pondérée sur 100.

Ce n'est PAS un modèle entraîné : c'est un algorithme à poids fixes (poids initiaux,
à réviser avec l'équipe). Seul le niveau de risque de maintenance vient du modèle XGBoost.

    sévérité                35 × CVSS / 10
    exploitabilité          25 × (1 si exploitation connue, sinon probabilité d'exploitation, sinon 0)
    exposition              20 × (1 en production, 0,25 en développement/test)
    importance dépendance   20 = 12 × (1 direct, 0,6 transitif) + 8 × (0 low, 0,5 medium, 1 high)
"""
from __future__ import annotations

from .schemas import RiskScoreRequest, RiskScoreResponse

WEIGHTS_VERSION = "w1-initial"
W_SEVERITY, W_EXPLOIT, W_EXPOSURE, W_DEP_RELATION, W_DEP_MAINT = 35, 25, 20, 12, 8
RELATION_FACTOR = {"direct": 1.0, "transitive": 0.6}
SCOPE_FACTOR = {"production": 1.0, "development": 0.25}
MAINT_FACTOR = {"low": 0.0, "medium": 0.5, "high": 1.0}


def priority_of(score: int) -> str:
    if score >= 80:
        return "critical"
    if score >= 60:
        return "high"
    if score >= 40:
        return "medium"
    return "low"


def risk_score(req: RiskScoreRequest) -> RiskScoreResponse:
    exploit = 1.0 if req.known_exploited else (req.exploit_probability or 0.0)
    parts = {
        "severity": W_SEVERITY * req.cvss / 10,
        "exploitability": W_EXPLOIT * exploit,
        "exposure": W_EXPOSURE * SCOPE_FACTOR[req.scope],
        "dependency": W_DEP_RELATION * RELATION_FACTOR[req.relation]
                      + W_DEP_MAINT * MAINT_FACTOR.get(req.maintenance_risk or "low", 0.0),
    }
    score = int(round(min(100.0, sum(parts.values()))))
    return RiskScoreResponse(
        vulnerability_id=req.vulnerability_id,
        score=score,
        priority=priority_of(score),
        breakdown={k: round(v, 2) for k, v in parts.items()},
        weights_version=WEIGHTS_VERSION,
    )
