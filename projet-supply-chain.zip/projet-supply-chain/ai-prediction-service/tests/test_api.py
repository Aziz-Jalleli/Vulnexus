import gzip
import json
import math
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import xgboost as xgb
from fastapi.testclient import TestClient

from app.features import FEATURE_NAMES, compute_features, parse_iso
from app.main import app

ROOT = Path(__file__).resolve().parent.parent
NOW = datetime(2026, 11, 27, tzinfo=timezone.utc)


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:  # déclenche le chargement du modèle (lifespan)
        yield c


def releases(days_ago):
    return [{"version": f"1.{i}.0", "published_at": (NOW - timedelta(days=x)).isoformat()}
            for i, x in enumerate(sorted(days_ago, reverse=True))]


def post_risk(client, days_ago, **kw):
    body = {"package": "demo", "releases": releases(days_ago), "as_of": NOW.isoformat(), **kw}
    return client.post("/v1/maintenance-risk", json=body)


# ---------------------------------------------------------------- santé / info
def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["model_loaded"] is True


def test_model_info_lists_limitations(client):
    j = client.get("/v1/model-info").json()
    assert j["features"] == FEATURE_NAMES and j["labels"] == ["low", "medium", "high"]
    assert any("npm" in s for s in j["limitations"])


# ---------------------------------------------------------------- risque de maintenance
def test_active_package_is_low(client):
    r = post_risk(client, list(range(5, 400, 10)))  # une version tous les 10 jours
    assert r.status_code == 200
    j = r.json()
    assert j["level"] == "low"
    assert math.isclose(sum(j["probabilities"].values()), 1.0, abs_tol=1e-4)
    assert len(j["top_factors"]) == 3


def test_abandoned_package_is_high(client):
    j = post_risk(client, [1500, 1600, 1700, 1800, 2000, 2400]).json()
    assert j["level"] == "high" and not j["deprecated_override"]


def test_deprecated_forces_high_and_says_so(client):
    j = post_risk(client, list(range(5, 400, 10)), deprecated=True).json()
    assert j["level"] == "high" and j["deprecated_override"] is True
    assert j["probabilities"]["low"] > j["probabilities"]["high"]  # probabilités du modèle conservées
    assert any("déprécié" in w for w in j["warnings"])


def test_maven_gets_a_warning(client):
    j = post_risk(client, list(range(5, 400, 10)), ecosystem="Maven").json()
    assert any("npm uniquement" in w for w in j["warnings"])


def test_few_releases_warning(client):
    j = post_risk(client, [30, 10]).json()
    assert any("Moins de 3 versions" in w for w in j["warnings"])


def test_no_release_before_as_of_is_422(client):
    body = {"package": "x", "releases": releases([10]), "as_of": (NOW - timedelta(days=100)).isoformat()}
    assert client.post("/v1/maintenance-risk", json=body).status_code == 422


@pytest.mark.parametrize("body", [
    {"package": "x", "releases": []},
    {"package": "", "releases": [{"version": "1.0.0", "published_at": "2024-01-01T00:00:00Z"}]},
    {"package": "x", "releases": [{"version": "1.0.0", "published_at": "pas une date"}]},
    {"package": "x", "ecosystem": "pip", "releases": [{"version": "1.0.0", "published_at": "2024-01-01T00:00:00Z"}]},
])
def test_invalid_payloads_are_422(client, body):
    assert client.post("/v1/maintenance-risk", json=body).status_code == 422


def test_batch(client):
    items = [{"package": "a", "releases": releases(list(range(5, 400, 10))), "as_of": NOW.isoformat()},
             {"package": "b", "releases": releases([1500, 1700, 2000]), "as_of": NOW.isoformat()}]
    j = client.post("/v1/maintenance-risk/batch", json={"items": items}).json()
    assert [x["package"] for x in j["results"]] == ["a", "b"]
    assert [x["level"] for x in j["results"]] == ["low", "high"]


def test_batch_too_large_is_422(client):
    item = {"package": "a", "releases": releases([5])}
    assert client.post("/v1/maintenance-risk/batch", json={"items": [item] * 501}).status_code == 422


# ---------------------------------------------------------------- parité entraînement / service
def test_train_serve_parity(client):
    """Le service doit recalculer exactement les caractéristiques et probabilités de l'entraînement."""
    hist = ROOT / "data" / "npm_release_history.jsonl.gz"
    test_csv = ROOT / "data" / "dataset_test.csv"
    if not (hist.exists() and test_csv.exists()):
        pytest.skip("données d'entraînement absentes")
    info = json.load(open(ROOT / "data" / "dataset_info.json"))
    t_test = datetime.fromisoformat(info["t_test"]).replace(tzinfo=timezone.utc)
    df = pd.read_csv(test_csv).set_index("package")
    booster = xgb.Booster()
    booster.load_model(str(ROOT / "models" / "maintenance_risk.json"))

    checked = 0
    with gzip.open(hist, "rt") as f:
        for line in f:
            row = json.loads(line)
            if "error" in row or row["name"] not in df.index:
                continue
            rel = [{"version": v, "published_at": t} for v, t in row["releases"] if isinstance(t, str)]
            r = client.post("/v1/maintenance-risk", json={"package": row["name"], "releases": rel,
                                                          "as_of": t_test.isoformat()})
            assert r.status_code == 200
            expected = df.loc[row["name"], FEATURE_NAMES].to_numpy(dtype=float)
            # caractéristiques identiques à celles du CSV d'entraînement
            feats = compute_features([(x["version"], parse_iso(x["published_at"])) for x in rel], t_test)
            got = np.array([feats[n] for n in FEATURE_NAMES], dtype=float)
            assert np.allclose(got, expected, equal_nan=True, rtol=1e-9, atol=1e-9)
            # probabilités identiques à celles du modèle hors service
            p = booster.predict(xgb.DMatrix(expected.reshape(1, -1), feature_names=FEATURE_NAMES))[0]
            api = r.json()["probabilities"]
            assert np.allclose([api["low"], api["medium"], api["high"]], p, atol=1e-6)
            checked += 1
            if checked == 25:
                break
    assert checked == 25


# ---------------------------------------------------------------- score de risque
def test_log4shell_style_score(client):
    r = client.post("/v1/risk-score", json={"vulnerability_id": "GHSA-jfh8-c2jp-5v3q", "cvss": 10,
                                            "known_exploited": True, "scope": "production",
                                            "relation": "direct", "maintenance_risk": "low"})
    j = r.json()
    assert j["score"] == 92 and j["priority"] == "critical"
    assert j["breakdown"] == {"severity": 35.0, "exploitability": 25.0, "exposure": 20.0, "dependency": 12.0}


def test_dev_only_transitive_is_lower(client):
    base = {"vulnerability_id": "X", "cvss": 8.0}
    prod = client.post("/v1/risk-score", json={**base, "scope": "production", "relation": "direct"}).json()
    dev = client.post("/v1/risk-score", json={**base, "scope": "development", "relation": "transitive"}).json()
    assert dev["score"] < prod["score"]


def test_exploit_probability_is_used(client):
    base = {"vulnerability_id": "X", "cvss": 5.0}
    a = client.post("/v1/risk-score", json=base).json()["breakdown"]["exploitability"]
    b = client.post("/v1/risk-score", json={**base, "exploit_probability": 0.4}).json()["breakdown"]["exploitability"]
    assert a == 0 and b == 10.0


@pytest.mark.parametrize("cvss", [-1, 10.1])
def test_cvss_out_of_range_is_422(client, cvss):
    assert client.post("/v1/risk-score", json={"vulnerability_id": "X", "cvss": cvss}).status_code == 422


def test_score_never_exceeds_100(client):
    j = client.post("/v1/risk-score", json={"vulnerability_id": "X", "cvss": 10, "known_exploited": True,
                                            "maintenance_risk": "high"}).json()
    assert j["score"] <= 100 and j["priority"] == "critical"
