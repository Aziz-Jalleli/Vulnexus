import math
from datetime import datetime, timedelta, timezone

from app.features import FEATURE_NAMES, compute_features, label_outcome

UTC = timezone.utc
T = datetime(2025, 1, 1, tzinfo=UTC)


def d(days_before_t: int) -> datetime:
    return T - timedelta(days=days_before_t)


def test_no_release_before_as_of_returns_none():
    assert compute_features([("1.0.0", T + timedelta(days=1))], T) is None


def test_only_past_releases_are_used():
    """Aucune fuite : une version publiée après T ne change pas les caractéristiques."""
    past = [("1.0.0", d(400)), ("1.1.0", d(100))]
    future = past + [("2.0.0", T + timedelta(days=5))]
    assert compute_features(past, T) == compute_features(future, T)


def test_known_values():
    rel = [("1.0.0", d(800)), ("1.1.0", d(400)), ("2.0.0-beta.1", d(30)), ("2.0.0", d(10))]
    f = compute_features(rel, T)
    assert f["days_since_last_release"] == 10
    assert f["days_since_last_stable_release"] == 10
    assert f["releases_12m"] == 2          # d(30), d(10)
    assert f["releases_prev_12m"] == 1     # d(400)
    assert f["releases_trend"] == 1
    assert f["releases_total"] == 4
    assert f["age_days"] == 800
    assert f["major_versions"] == 2
    assert f["prerelease_share_12m"] == 0.5


def test_single_release_gives_nan_gaps_not_crash():
    f = compute_features([("1.0.0", d(5))], T)
    assert math.isnan(f["mean_gap_days"]) and math.isnan(f["gap_cv"])
    assert f["releases_total"] == 1


def test_only_prereleases_has_no_stable_date():
    f = compute_features([("1.0.0-rc.1", d(5))], T)
    assert math.isnan(f["days_since_last_stable_release"])


def test_naive_datetimes_are_treated_as_utc():
    naive = datetime(2024, 12, 1)
    assert compute_features([("1.0.0", naive)], T)["days_since_last_release"] == 31


def test_feature_dict_has_all_names():
    f = compute_features([("1.0.0", d(5)), ("1.0.1", d(1))], T)
    assert list(f) == FEATURE_NAMES


def test_labels():
    rel = lambda *days: [("1.0.%d" % i, T + timedelta(days=x)) for i, x in enumerate(days)]
    end = T + timedelta(days=365)
    assert label_outcome(rel(), False, T, end) == "high"
    assert label_outcome(rel(10), False, T, end) == "medium"
    assert label_outcome(rel(10, 20), False, T, end) == "low"
    assert label_outcome(rel(10, 20, 30), True, T, end) == "high"   # déprécié
    assert label_outcome(rel(400), False, T, end) == "high"          # hors fenêtre
    assert label_outcome(rel(-5), False, T, end) == "high"           # avant T
