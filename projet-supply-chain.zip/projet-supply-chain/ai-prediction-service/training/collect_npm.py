#!/usr/bin/env python3
"""Collecte l'historique des versions de paquets npm populaires (registre npm public).

Pour chaque paquet, on ne garde que : nom, dates de publication de chaque version,
indicateur de dépréciation de la dernière version. Sortie : JSON lines compressé.

Source des noms : paquet npm `npm-high-impact` (liste de ~17 000 paquets à fort impact).
Échantillon aléatoire reproductible (graine 42).

Usage : python3 training/collect_npm.py --n 3000
"""
import argparse, gzip, json, random, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import quote

import httpx

ROOT = Path(__file__).resolve().parent.parent
NAMES = ROOT / "data" / "npm_high_impact_names.json"
OUT = ROOT / "data" / "npm_release_history.jsonl.gz"


def fetch(client: httpx.Client, name: str, retries: int = 4):
    url = "https://registry.npmjs.org/" + quote(name, safe="@")
    for attempt in range(retries):
        try:
            r = client.get(url, timeout=60)
            if r.status_code == 404:
                return {"name": name, "error": "404"}
            if r.status_code == 200:
                d = r.json()
                time_map = d.get("time", {})
                versions = d.get("versions", {})
                latest = (d.get("dist-tags") or {}).get("latest")
                dep = None
                if latest and latest in versions:
                    dep = versions[latest].get("deprecated")
                releases = [[v, t] for v, t in time_map.items() if v not in ("created", "modified")]
                return {
                    "name": name,
                    "created": time_map.get("created"),
                    "latest": latest,
                    "deprecated": bool(dep),
                    "releases": releases,
                }
            time.sleep(1.5 * (attempt + 1))
        except Exception:
            time.sleep(1.5 * (attempt + 1))
    return {"name": name, "error": "failed"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--workers", type=int, default=12)
    a = ap.parse_args()

    names = json.load(open(NAMES))
    random.Random(a.seed).shuffle(names)
    names = names[: a.n]

    done = set()
    if OUT.exists():
        with gzip.open(OUT, "rt") as f:
            for line in f:
                done.add(json.loads(line)["name"])
    todo = [n for n in names if n not in done]
    print(f"{len(done)} déjà collectés, {len(todo)} à collecter", flush=True)

    t0 = time.time()
    with httpx.Client(http2=False, headers={"User-Agent": "supply-chain-student-project"},
                      limits=httpx.Limits(max_connections=a.workers)) as client, \
         gzip.open(OUT, "at") as out, ThreadPoolExecutor(a.workers) as ex:
        futs = {ex.submit(fetch, client, n): n for n in todo}
        for i, fut in enumerate(as_completed(futs), 1):
            out.write(json.dumps(fut.result(), separators=(",", ":")) + "\n")
            if i % 100 == 0:
                out.flush()
                print(f"{i}/{len(todo)}  {time.time()-t0:.0f}s", flush=True)
    print("terminé", flush=True)


if __name__ == "__main__":
    main()
