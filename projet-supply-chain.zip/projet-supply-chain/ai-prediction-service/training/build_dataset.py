#!/usr/bin/env python3
"""Construit les jeux d'entraînement et de test à partir des historiques npm.

Deux instantanés, pour une validation DANS LE TEMPS :

    entraînement : T_train = date de collecte - 24 mois
                   caractéristiques avant T_train, étiquette = 12 mois après T_train
    test         : T_test  = date de collecte - 12 mois
                   caractéristiques avant T_test,  étiquette = 12 mois après T_test (jusqu'à la collecte)

Les étiquettes d'entraînement sont toutes connues AVANT T_test : le test porte donc
sur un futur que le modèle n'a jamais vu.

Usage : python3 training/build_dataset.py
"""
import gzip, json, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app.features import (FEATURE_NAMES, LABEL_WINDOW_DAYS, compute_features,  # noqa: E402
                          label_outcome, parse_iso)

HISTORY = ROOT / "data" / "npm_release_history.jsonl.gz"
META = ROOT / "data" / "collection_meta.json"


def load_packages():
    pkgs = []
    with gzip.open(HISTORY, "rt") as f:
        for line in f:
            r = json.loads(line)
            if "error" in r:
                continue
            releases = []
            for v, t in r["releases"]:
                if isinstance(t, str):  # ignore l'entrée "unpublished" (dict)
                    releases.append((v, parse_iso(t)))
            if releases:
                pkgs.append({"name": r["name"], "deprecated": r["deprecated"], "releases": releases})
    return pkgs


def build(pkgs, t, window_end):
    rows = []
    for p in pkgs:
        feats = compute_features(p["releases"], t)
        if feats is None:  # le paquet n'existait pas encore à la date T
            continue
        label = label_outcome(p["releases"], p["deprecated"], t, window_end)
        rows.append({"package": p["name"], **feats, "label": label})
    return pd.DataFrame(rows, columns=["package", *FEATURE_NAMES, "label"])


def main():
    collected = datetime.fromisoformat(json.load(open(META))["collected_at"]).replace(tzinfo=timezone.utc)
    w = timedelta(days=LABEL_WINDOW_DAYS)
    t_train, t_test = collected - 2 * w, collected - w
    pkgs = load_packages()

    train = build(pkgs, t_train, t_train + w)
    test = build(pkgs, t_test, collected)
    train.to_csv(ROOT / "data" / "dataset_train.csv", index=False)
    test.to_csv(ROOT / "data" / "dataset_test.csv", index=False)

    info = {
        "collected_at": collected.date().isoformat(),
        "t_train": t_train.date().isoformat(), "train_label_window_end": (t_train + w).date().isoformat(),
        "t_test": t_test.date().isoformat(), "test_label_window_end": collected.date().isoformat(),
        "n_train": len(train), "n_test": len(test),
        "label_distribution_train": train["label"].value_counts().to_dict(),
        "label_distribution_test": test["label"].value_counts().to_dict(),
    }
    json.dump(info, open(ROOT / "data" / "dataset_info.json", "w"), indent=2)
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
