#!/usr/bin/env python3
"""Entraîne et évalue le classifieur de risque de maintenance (XGBoost).

Comparaison sur le jeu de TEST (futur jamais vu) :
    0. classe majoritaire
    1. règle simple         (>= 730 j sans version => high, >= 365 j => medium, sinon low)
    2. régression logistique
    3. XGBoost              (réglage par validation croisée sur l'entraînement uniquement)

Sorties : models/maintenance_risk.json, models/metadata.json,
          reports/metrics.json, reports/EVALUATION.md

Usage : python3 training/train.py
"""
import json, sys, time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
import xgboost as xgb
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, f1_score, precision_recall_fscore_support
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from sklearn.utils.class_weight import compute_sample_weight

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from app.features import FEATURE_LABELS, FEATURE_NAMES, LABELS  # noqa: E402

SEED = 42
L2I = {l: i for i, l in enumerate(LABELS)}


def signed_log1p(x):
    return np.sign(x) * np.log1p(np.abs(x))


def rule_predict(df: pd.DataFrame) -> np.ndarray:
    d = df["days_since_last_release"].to_numpy()
    return np.where(d >= 730, L2I["high"], np.where(d >= 365, L2I["medium"], L2I["low"]))


def macro_f1(y, p):
    return f1_score(y, p, average="macro", labels=[0, 1, 2], zero_division=0)


def report(y, p):
    pr, rc, f1, sup = precision_recall_fscore_support(y, p, labels=[0, 1, 2], zero_division=0)
    return {
        "macro_f1": float(macro_f1(y, p)),
        "accuracy": float((y == p).mean()),
        "per_class": {LABELS[i]: {"precision": float(pr[i]), "recall": float(rc[i]),
                                  "f1": float(f1[i]), "support": int(sup[i])} for i in range(3)},
        "confusion_matrix": confusion_matrix(y, p, labels=[0, 1, 2]).tolist(),
    }


def bootstrap_ci(y, preds: dict, n=1000, seed=SEED):
    rng = np.random.default_rng(seed)
    scores = {k: [] for k in preds}
    diffs, diffs_lr = [], []
    for _ in range(n):
        idx = rng.integers(0, len(y), len(y))
        s = {k: macro_f1(y[idx], p[idx]) for k, p in preds.items()}
        for k, v in s.items():
            scores[k].append(v)
        diffs.append(s["xgboost"] - s["rule"])
        diffs_lr.append(s["xgboost"] - s["logistic_regression"])
    ci = {k: [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))] for k, v in scores.items()}
    ci["xgboost_minus_rule"] = [float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5))]
    ci["xgboost_minus_logreg"] = [float(np.percentile(diffs_lr, 2.5)), float(np.percentile(diffs_lr, 97.5))]
    return ci


def main():
    t0 = time.time()
    tr = pd.read_csv(ROOT / "data" / "dataset_train.csv")
    te = pd.read_csv(ROOT / "data" / "dataset_test.csv")
    info = json.load(open(ROOT / "data" / "dataset_info.json"))
    Xtr, ytr = tr[FEATURE_NAMES], tr["label"].map(L2I).to_numpy()
    Xte, yte = te[FEATURE_NAMES], te["label"].map(L2I).to_numpy()
    wtr = compute_sample_weight("balanced", ytr)

    # --- 0/1. références simples -------------------------------------------------
    preds = {"majority": np.full(len(yte), np.bincount(ytr).argmax()), "rule": rule_predict(te)}

    # --- 2. régression logistique ------------------------------------------------
    lr = make_pipeline(SimpleImputer(strategy="median"), FunctionTransformer(signed_log1p),
                       StandardScaler(), LogisticRegression(class_weight="balanced", max_iter=3000))
    lr.fit(Xtr, ytr)
    preds["logistic_regression"] = lr.predict(Xte)

    # --- 3. XGBoost : réglage par validation croisée (entraînement uniquement) ---
    space = {
        "max_depth": [2, 3, 4, 5, 6],
        "learning_rate": [0.03, 0.05, 0.1, 0.2],
        "n_estimators": [100, 200, 300, 400],
        "subsample": [0.7, 0.85, 1.0],
        "colsample_bytree": [0.7, 0.85, 1.0],
        "min_child_weight": [1, 3, 5, 10],
        "reg_lambda": [1.0, 5.0, 10.0],
    }
    base = xgb.XGBClassifier(objective="multi:softprob", num_class=3, tree_method="hist",
                             eval_metric="mlogloss", random_state=SEED, n_jobs=2)
    search = RandomizedSearchCV(base, space, n_iter=25, scoring="f1_macro", random_state=SEED,
                                cv=StratifiedKFold(5, shuffle=True, random_state=SEED), n_jobs=1, refit=False)
    search.fit(Xtr, ytr, sample_weight=wtr)
    best = search.best_params_
    print("meilleurs hyperparamètres :", best, "| F1 macro CV :", round(search.best_score_, 4), flush=True)

    model = xgb.XGBClassifier(objective="multi:softprob", num_class=3, tree_method="hist",
                              eval_metric="mlogloss", random_state=SEED, n_jobs=2, **best)
    model.fit(Xtr, ytr, sample_weight=wtr)
    preds["xgboost"] = model.predict(Xte)

    # --- évaluation ---------------------------------------------------------------
    active = (te["releases_12m"] >= 1).to_numpy()   # paquets encore actifs à la date T
    names = ["majority", "rule", "logistic_regression", "xgboost"]
    metrics = {
        "test_all": {k: report(yte, preds[k]) for k in names},
        "test_active_at_T": {k: report(yte[active], preds[k][active]) for k in names},
        "n_test_active_at_T": int(active.sum()),
        "bootstrap_95ci_macro_f1": bootstrap_ci(yte, preds),
        "bootstrap_95ci_macro_f1_active": bootstrap_ci(yte[active], {k: p[active] for k, p in preds.items()}),
        "cv_macro_f1_xgboost_train": float(search.best_score_),
        "best_params": best,
    }

    # --- importance des caractéristiques (contributions SHAP natives XGBoost) ----
    contrib = model.get_booster().predict(xgb.DMatrix(Xte), pred_contribs=True)  # (n, classes, feats+1)
    imp = np.abs(contrib[:, :, :-1]).mean(axis=(0, 1))
    metrics["feature_importance_mean_abs_shap"] = {
        FEATURE_NAMES[i]: float(imp[i]) for i in np.argsort(-imp)}

    # --- sauvegarde ---------------------------------------------------------------
    (ROOT / "models").mkdir(exist_ok=True)
    (ROOT / "reports").mkdir(exist_ok=True)
    model.get_booster().save_model(str(ROOT / "models" / "maintenance_risk.json"))
    meta = {
        "model_version": "xgb-npm-" + info["collected_at"],
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "labels": LABELS, "features": FEATURE_NAMES, "feature_labels": FEATURE_LABELS,
        "dataset": info, "best_params": best,
        "versions": {"xgboost": xgb.__version__, "scikit-learn": sklearn.__version__},
        "test_macro_f1": metrics["test_all"]["xgboost"]["macro_f1"],
        "trained_on": "npm uniquement (3000 paquets de la liste npm-high-impact)",
    }
    json.dump(meta, open(ROOT / "models" / "metadata.json", "w"), indent=2, ensure_ascii=False)
    json.dump(metrics, open(ROOT / "reports" / "metrics.json", "w"), indent=2)
    write_markdown(metrics, info)
    print(f"terminé en {time.time()-t0:.0f}s")


def write_markdown(m, info):
    fr = {"majority": "Classe majoritaire", "rule": "Règle simple (jours sans version)",
          "logistic_regression": "Régression logistique", "xgboost": "XGBoost"}
    ci_all, ci_act = m["bootstrap_95ci_macro_f1"], m["bootstrap_95ci_macro_f1_active"]

    def table(section, ci):
        rows = ["| Modèle | F1 macro | IC 95 % | Exactitude | F1 low | F1 medium | F1 high |", "|---|---|---|---|---|---|---|"]
        for k in ["majority", "rule", "logistic_regression", "xgboost"]:
            r = m[section][k]
            rows.append(f"| {fr[k]} | {r['macro_f1']:.3f} | [{ci[k][0]:.3f} ; {ci[k][1]:.3f}] | {r['accuracy']:.3f} | "
                        + " | ".join(f"{r['per_class'][c]['f1']:.3f}" for c in LABELS) + " |")
        return "\n".join(rows)

    cm = m["test_all"]["xgboost"]["confusion_matrix"]
    imp = list(m["feature_importance_mean_abs_shap"].items())[:6]
    d_all, d_act = ci_all["xgboost_minus_rule"], ci_act["xgboost_minus_rule"]
    l_all, l_act = ci_all["xgboost_minus_logreg"], ci_act["xgboost_minus_logreg"]

    def verdict(lo, hi):
        return ("XGBoost est meilleur" if lo > 0 else "la régression logistique est meilleure" if hi < 0
                else "différence non significative (l'intervalle contient 0)")
    md = f"""# Évaluation du classifieur de risque de maintenance

*Fichier généré par `training/train.py` : ne pas modifier à la main.*

## Protocole

| | Entraînement | Test |
|---|---|---|
| Date T (caractéristiques calculées avant T) | {info['t_train']} | {info['t_test']} |
| Fenêtre d'étiquetage (12 mois après T) | jusqu'au {info['train_label_window_end']} | jusqu'au {info['test_label_window_end']} |
| Paquets | {info['n_train']} | {info['n_test']} |
| high / medium / low | {info['label_distribution_train'].get('high')} / {info['label_distribution_train'].get('medium')} / {info['label_distribution_train'].get('low')} | {info['label_distribution_test'].get('high')} / {info['label_distribution_test'].get('medium')} / {info['label_distribution_test'].get('low')} |

Le test porte sur un futur que le modèle n'a pas vu : toutes les étiquettes d'entraînement sont connues avant la date T du test.
Les hyperparamètres de XGBoost sont réglés par validation croisée (5 plis) sur l'entraînement uniquement.

**Étiquette (ce qui se passe dans les 12 mois suivant T) :** `high` = dernière version dépréciée OU aucune version publiée ;
`medium` = exactement 1 version ; `low` = 2 versions ou plus.

## Résultats sur le jeu de test (tous les paquets)

{table('test_all', ci_all)}

Différence XGBoost − règle simple (F1 macro) : IC 95 % bootstrap [{d_all[0]:+.3f} ; {d_all[1]:+.3f}].
Différence XGBoost − régression logistique : [{l_all[0]:+.3f} ; {l_all[1]:+.3f}] : {verdict(*l_all)}.

## Résultats sur les paquets encore actifs à la date T ({m['n_test_active_at_T']} paquets, au moins 1 version sur les 12 mois précédents)

C'est le cas le plus utile : prédire si un paquet actif va s'arrêter. La règle « jours sans version » y est moins informative.

{table('test_active_at_T', ci_act)}

Différence XGBoost − règle simple (F1 macro) : IC 95 % bootstrap [{d_act[0]:+.3f} ; {d_act[1]:+.3f}].
(Sur ce sous-ensemble, la règle ne peut prédire que `low` puisque tous ces paquets ont publié il y a moins de 365 jours : la comparaison avec elle est donc peu exigeante.)
Différence XGBoost − régression logistique : [{l_act[0]:+.3f} ; {l_act[1]:+.3f}] : {verdict(*l_act)}.

## Matrice de confusion XGBoost (test, lignes = réel, colonnes = prédit : low, medium, high)

| | low | medium | high |
|---|---|---|---|
| **low** | {cm[0][0]} | {cm[0][1]} | {cm[0][2]} |
| **medium** | {cm[1][0]} | {cm[1][1]} | {cm[1][2]} |
| **high** | {cm[2][0]} | {cm[2][1]} | {cm[2][2]} |

## Caractéristiques les plus influentes (moyenne des |valeurs SHAP|)

""" + "\n".join(f"{i+1}. `{k}` : {v:.3f}" for i, (k, v) in enumerate(imp)) + """

## Limites

- **« high » ne veut pas dire « dangereux » :** beaucoup de bibliothèques populaires sont terminées et stables (aucune nouvelle version ne signifie parfois « rien à corriger »). L'étiquette mesure l'absence de maintenance attendue, pas un défaut.
- **Une seule source de signaux :** l'historique des versions du registre npm. Les commits, issues et contributeurs (API GitHub) ne sont pas encore utilisés.
- **npm uniquement :** aucun jeu de données Maven n'a été collecté (Maven Central n'est pas accessible depuis l'environnement de développement). Appliquer le modèle à Maven est une extrapolation non validée.
- **Dépréciation :** le drapeau « déprécié » est l'état actuel ; sa date n'est pas connue.
- **Paquets populaires uniquement** (liste `npm-high-impact`) : les résultats ne s'appliquent pas forcément à de petits paquets.
"""
    (ROOT / "reports" / "EVALUATION.md").write_text(md, encoding="utf-8")


if __name__ == "__main__":
    main()
